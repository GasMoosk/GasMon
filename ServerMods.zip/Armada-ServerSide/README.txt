HHH


Noted Items
 - 64? BackPack Mod
 - Improved Food %
 - Updated HUD with HUD+
 - Fixed Display Values for Foods
 - 24/7 Traders
 - 3 Slot Forge
 - 12 Slot Que
 - Craftable Game Items / Lights
 - Working Ovens/grills
 - Better NailGun/Auger/Chainsaw
 - Better Stamina
 - Learn By Doing
 - Auto Stop Fuel
 - Less Car Damage
 - Better Traps
 - Pick up Spike Traps
 - 2x Most Stacks Only (Not Bundles)
 - Bird Nest Incrased
 - Lootable Zombies 
 - Extra Lootable Items
	Ham Radio
	tvCRT
	ServerRacks
	IceMachine
	DecoArmyTruck
	Military Crate Covered/Uncovered
	Non-Use Vending Machine
	TableSaw
	IVStand